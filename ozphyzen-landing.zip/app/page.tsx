"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  CheckCircle2,
  Snowflake,
  Leaf,
  Zap,
  Hand,
  Shield,
  Truck,
  CreditCard,
  Star,
  Clock,
  Package,
  ChevronDown,
  Award,
  Lock,
  RefreshCw,
} from "lucide-react"

export default function OzphyzenLanding() {
  const [timeLeft, setTimeLeft] = useState({ hours: 23, minutes: 45, seconds: 30 })
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    city: "",
    address: "",
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Form submitted:", formData)
    alert("Siparişiniz alındı! En kısa sürede sizinle iletişime geçeceğiz.")
  }

  const scrollToForm = () => {
    document.getElementById("order-form")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/20">
      <div className="bg-gradient-to-r from-primary/95 via-primary to-primary/95 border-b border-primary-foreground/10 py-3 px-4">
        <div className="container mx-auto flex flex-wrap items-center justify-center gap-x-8 gap-y-2 text-sm text-primary-foreground">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="font-medium">SSL Güvenli Ödeme</span>
          </div>
          <div className="flex items-center gap-2">
            <Award className="h-4 w-4" />
            <span className="font-medium">Kozmetik Ürün Sertifikası</span>
          </div>
          <div className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" />
            <span className="font-medium">14 Gün İade Garantisi</span>
          </div>
        </div>
      </div>

      <section className="container mx-auto px-4 py-8 md:py-16">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-6 lg:pr-8">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-success/10 to-primary/10 border border-success/20 text-foreground px-4 py-2 rounded-full text-sm font-semibold shadow-sm">
              <Leaf className="h-4 w-4 text-success" />
              Doğal İçerikli • Dermatolojik Test Edilmiş
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-balance leading-[1.1] tracking-tight">
              Günlük Konforunuz İçin <span className="text-primary">Ferahlatıcı Dokunuş</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Mentol ve doğal yağların gücüyle formüle edilmiş OZPHYZEN, günlük konforunuz için özel olarak
              geliştirilmiş premium masaj jelidir.
            </p>

            <div className="flex flex-wrap gap-3 py-2">
              <div className="flex items-center gap-2 bg-muted/50 px-3 py-2 rounded-lg border border-border/50">
                <CheckCircle2 className="h-4 w-4 text-success" />
                <span className="text-sm font-medium">5.000+ Mutlu Müşteri</span>
              </div>
              <div className="flex items-center gap-2 bg-muted/50 px-3 py-2 rounded-lg border border-border/50">
                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                <span className="text-sm font-medium">4.8/5 Müşteri Puanı</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <Button
                size="lg"
                className="text-lg px-8 py-6 shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all"
                onClick={scrollToForm}
              >
                Hemen Sipariş Ver
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-6 border-2 bg-transparent"
                onClick={scrollToForm}
              >
                Ürün Detayları
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-border/50">
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center flex-shrink-0">
                  <Truck className="h-5 w-5 text-success" />
                </div>
                <span className="text-sm font-medium leading-tight">Ücretsiz Kargo</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <CreditCard className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm font-medium leading-tight">Kapıda Ödeme</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center flex-shrink-0">
                  <RefreshCw className="h-5 w-5 text-success" />
                </div>
                <span className="text-sm font-medium leading-tight">14 Gün İade</span>
              </div>
            </div>
          </div>

          <div className="relative lg:pl-8">
            <div className="relative aspect-square bg-gradient-to-br from-primary/10 via-background to-success/10 rounded-3xl border border-border/50 shadow-2xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
              <img
                src="/ozphyzen-massage-gel-bottle-with-menthol-and-natur.jpg"
                alt="OZPHYZEN Ferahlatıcı Masaj Jeli"
                className="relative w-full h-full object-contain p-12 drop-shadow-2xl"
              />
            </div>

            <div className="absolute -top-4 -right-4 bg-gradient-to-br from-urgent to-urgent/90 text-white px-6 py-4 rounded-2xl shadow-2xl border-4 border-background">
              <div className="text-xs font-semibold uppercase tracking-wide opacity-90">Özel Kampanya</div>
              <div className="text-3xl font-bold">399₺</div>
              <div className="text-sm line-through opacity-75">599₺</div>
            </div>

            <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-background border-2 border-urgent/20 px-6 py-3 rounded-full shadow-lg">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <div className="h-2 w-2 rounded-full bg-urgent animate-pulse" />
                <span>Stokta Sadece 47 Adet Kaldı</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Neden OZPHYZEN?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Premium formülümüz ile günlük konforunuzu artırın</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-2 hover:border-primary hover:shadow-lg transition-all duration-300 group">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Snowflake className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold">Ferahlatıcı Etki</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Mentol içeriği ile anında ferahlık hissi ve günlük konfor
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-success hover:shadow-lg transition-all duration-300 group">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-success/20 to-success/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Leaf className="h-6 w-6 text-success" />
                </div>
                <h3 className="text-lg font-bold">Doğal İçerik</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Arnika, okaliptüs ve kafur yağı ile zenginleştirilmiş formül
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary hover:shadow-lg transition-all duration-300 group">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Hand className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold">Kolay Uygulama</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Hızlı emilen, yapışkan olmayan premium formül
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-success hover:shadow-lg transition-all duration-300 group">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-success/20 to-success/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Zap className="h-6 w-6 text-success" />
                </div>
                <h3 className="text-lg font-bold">Hızlı Etki</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Uygulandıktan hemen sonra hissedilen rahatlama
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Product Details */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-balance">Ürün Detayları</h2>
              <div className="space-y-4">
                <h3 className="text-xl font-semibold">İçerik</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>Mentol - Ferahlatıcı ve serinletici etki</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>Arnika Yağı - Doğal destek sağlar</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>Okaliptüs Yağı - Ferahlatıcı aroma</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>Kafur - Serinletici his</span>
                  </li>
                </ul>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold">Özellikler</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>100ml şişe ambalaj</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>Pratik pompa başlık</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>Hızlı emilim formülü</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
                    <span>Yapışkan olmayan doku</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-xl font-semibold">Nasıl Kullanılır?</h3>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Temiz ve Kuru Cilt</h4>
                    <p className="text-muted-foreground">
                      Uygulamadan önce cildinizin temiz ve kuru olduğundan emin olun.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Uygun Miktarda Uygulayın</h4>
                    <p className="text-muted-foreground">
                      Bölgeye uygun miktarda jel sürün ve dairesel hareketlerle masaj yapın.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Masaj Yapın</h4>
                    <p className="text-muted-foreground">Jel tamamen emilene kadar nazikçe masaj yapın.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold flex-shrink-0">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Günde 2-3 Kez</h4>
                    <p className="text-muted-foreground">İhtiyaç duyduğunuzda günde 2-3 kez tekrarlayabilirsiniz.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-muted/30 py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Müşterilerimiz Ne Diyor?</h2>
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="font-semibold">4.8/5</span>
              <span>•</span>
              <span>5.000+ Değerlendirme</span>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-10">
            <Card className="border-2 hover:shadow-lg transition-shadow">
              <CardContent className="p-6 space-y-3">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  "Günlük kullanımda çok memnunum. Ferahlatıcı etkisi gerçekten hissediliyor. Doğal içeriği olması da
                  benim için çok önemli."
                </p>
                <div className="flex items-center gap-2 pt-2 border-t border-border/50">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                    AK
                  </div>
                  <div className="text-sm font-semibold">Ayşe K.</div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 hover:shadow-lg transition-shadow">
              <CardContent className="p-6 space-y-3">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  "Hızlı kargo ve kaliteli ürün. Mentol etkisi çok güzel, yapışkan değil ve hemen emiliyor. Kesinlikle
                  tavsiye ederim."
                </p>
                <div className="flex items-center gap-2 pt-2 border-t border-border/50">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                    MY
                  </div>
                  <div className="text-sm font-semibold">Mehmet Y.</div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 hover:shadow-lg transition-shadow">
              <CardContent className="p-6 space-y-3">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  "Spor sonrası kullanıyorum, çok rahatlatıcı. Fiyat performans olarak da çok iyi. İkinci şişemi aldım."
                </p>
                <div className="flex items-center gap-2 pt-2 border-t border-border/50">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                    ZD
                  </div>
                  <div className="text-sm font-semibold">Zeynep D.</div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
            <div className="flex flex-col items-center text-center gap-3 p-6 bg-background rounded-xl border-2 border-border/50 hover:border-primary/50 transition-colors">
              <div className="h-14 w-14 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <Lock className="h-7 w-7 text-primary" />
              </div>
              <div>
                <div className="font-bold text-sm mb-1">SSL Güvenli Ödeme</div>
                <div className="text-xs text-muted-foreground">256-bit şifreleme</div>
              </div>
            </div>
            <div className="flex flex-col items-center text-center gap-3 p-6 bg-background rounded-xl border-2 border-border/50 hover:border-success/50 transition-colors">
              <div className="h-14 w-14 rounded-full bg-gradient-to-br from-success/20 to-success/10 flex items-center justify-center">
                <Truck className="h-7 w-7 text-success" />
              </div>
              <div>
                <div className="font-bold text-sm mb-1">Ücretsiz Kargo</div>
                <div className="text-xs text-muted-foreground">Tüm Türkiye'ye</div>
              </div>
            </div>
            <div className="flex flex-col items-center text-center gap-3 p-6 bg-background rounded-xl border-2 border-border/50 hover:border-primary/50 transition-colors">
              <div className="h-14 w-14 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <CreditCard className="h-7 w-7 text-primary" />
              </div>
              <div>
                <div className="font-bold text-sm mb-1">Kapıda Ödeme</div>
                <div className="text-xs text-muted-foreground">Güvenli teslimat</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-6 bg-gradient-to-r from-urgent/10 via-urgent/5 to-urgent/10 border-y-2 border-urgent/20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 text-center">
            <div className="flex items-center gap-3 bg-background/80 backdrop-blur-sm px-6 py-4 rounded-xl border-2 border-urgent/30 shadow-lg">
              <Clock className="h-8 w-8 text-urgent flex-shrink-0" />
              <div className="text-left">
                <div className="font-bold text-lg text-foreground">Kampanya Bitiyor!</div>
                <div className="text-2xl font-mono font-bold text-urgent tabular-nums">
                  {String(timeLeft.hours).padStart(2, "0")}:{String(timeLeft.minutes).padStart(2, "0")}:
                  {String(timeLeft.seconds).padStart(2, "0")}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-background/80 backdrop-blur-sm px-6 py-4 rounded-xl border-2 border-urgent/30 shadow-lg">
              <Package className="h-8 w-8 text-urgent flex-shrink-0" />
              <div className="text-left">
                <div className="font-bold text-lg text-foreground">Son Ürünler</div>
                <div className="text-xl font-bold text-urgent">Sadece 47 Adet Kaldı</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="order-form" className="py-12 md:py-20 bg-gradient-to-br from-primary/5 via-background to-success/5">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <Card className="border-2 shadow-2xl">
              <CardContent className="p-8 md:p-10">
                <div className="text-center mb-8">
                  <div className="inline-flex items-center gap-2 bg-success/10 text-success px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <CheckCircle2 className="h-4 w-4" />
                    Güvenli Sipariş Formu
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold mb-3">Hemen Sipariş Verin</h2>
                  <p className="text-muted-foreground mb-6">Formu doldurun, 2-4 iş günü içinde kapınızda olsun</p>

                  <div className="inline-flex items-center gap-4 bg-gradient-to-r from-urgent/10 to-urgent/5 border-2 border-urgent/20 rounded-2xl px-6 py-4 relative">
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Kampanya Fiyatı</div>
                      <div className="text-4xl font-bold text-primary">399₺</div>
                    </div>
                    <div className="h-12 w-px bg-border" />
                    <div>
                      <div className="text-sm text-muted-foreground line-through mb-1">Normal Fiyat</div>
                      <div className="text-2xl font-semibold text-muted-foreground line-through">599₺</div>
                    </div>
                    <div className="absolute -top-3 -right-3 bg-urgent text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                      %33 İNDİRİM
                    </div>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-sm font-semibold">
                      Ad Soyad *
                    </Label>
                    <Input
                      id="name"
                      required
                      placeholder="Adınız ve soyadınız"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="h-12 border-2 focus:border-primary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-sm font-semibold">
                      Telefon *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      required
                      placeholder="0555 555 55 55"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="h-12 border-2 focus:border-primary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="city" className="text-sm font-semibold">
                      Şehir *
                    </Label>
                    <select
                      id="city"
                      required
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="flex h-12 w-full rounded-md border-2 border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20"
                    >
                      <option value="">Şehir seçiniz</option>
                      <option value="İstanbul">İstanbul</option>
                      <option value="Ankara">Ankara</option>
                      <option value="İzmir">İzmir</option>
                      <option value="Bursa">Bursa</option>
                      <option value="Antalya">Antalya</option>
                      <option value="Adana">Adana</option>
                      <option value="Konya">Konya</option>
                      <option value="Gaziantep">Gaziantep</option>
                      <option value="Diğer">Diğer</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address" className="text-sm font-semibold">
                      Adres *
                    </Label>
                    <textarea
                      id="address"
                      required
                      placeholder="Teslimat adresiniz"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="flex min-h-[100px] w-full rounded-md border-2 border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20"
                    />
                  </div>

                  <div className="space-y-4 pt-2">
                    <Button
                      type="submit"
                      size="lg"
                      className="w-full text-lg py-7 shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 transition-all"
                    >
                      <Lock className="h-5 w-5 mr-2" />
                      Güvenli Sipariş Ver (Kapıda Ödeme)
                    </Button>

                    <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Shield className="h-3 w-3" />
                        <span>SSL Güvenli</span>
                      </div>
                      <div className="h-3 w-px bg-border" />
                      <div className="flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        <span>Ücretsiz Kargo</span>
                      </div>
                      <div className="h-3 w-px bg-border" />
                      <div className="flex items-center gap-1">
                        <RefreshCw className="h-3 w-3" />
                        <span>14 Gün İade</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-center text-muted-foreground pt-2">
                    Siparişinizi tamamlayarak{" "}
                    <a href="#" className="underline hover:text-foreground">
                      Mesafeli Satış Sözleşmesi
                    </a>{" "}
                    ve{" "}
                    <a href="#" className="underline hover:text-foreground">
                      Gizlilik Politikası
                    </a>
                    'nı kabul etmiş olursunuz.
                  </p>
                </form>
              </CardContent>
            </Card>

            <div className="mt-6 grid grid-cols-3 gap-3">
              <div className="bg-background border border-border/50 rounded-lg p-3 text-center">
                <Shield className="h-6 w-6 text-success mx-auto mb-1" />
                <div className="text-xs font-semibold">Güvenli Ödeme</div>
              </div>
              <div className="bg-background border border-border/50 rounded-lg p-3 text-center">
                <Truck className="h-6 w-6 text-success mx-auto mb-1" />
                <div className="text-xs font-semibold">Hızlı Teslimat</div>
              </div>
              <div className="bg-background border border-border/50 rounded-lg p-3 text-center">
                <Award className="h-6 w-6 text-success mx-auto mb-1" />
                <div className="text-xs font-semibold">Kalite Garantisi</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Sıkça Sorulan Sorular</h2>
            <p className="text-muted-foreground">Merak ettiklerinizin cevapları</p>
          </div>
          <div className="max-w-3xl mx-auto space-y-3">
            {[
              {
                q: "OZPHYZEN nedir?",
                a: "OZPHYZEN, mentol ve doğal yağlar (arnika, okaliptüs, kafur) içeren ferahlatıcı bir masaj jelidir. Kozmetik bir üründür ve günlük konforunuz için tasarlanmıştır.",
              },
              {
                q: "Nasıl kullanılır?",
                a: "Temiz ve kuru cilde uygun miktarda uygulayın. Dairesel hareketlerle masaj yaparak cildinize emilmesini sağlayın. Günde 2-3 kez kullanabilirsiniz.",
              },
              {
                q: "Yan etkileri var mı?",
                a: "OZPHYZEN doğal içeriklerle formüle edilmiştir. Ancak herhangi bir alerjiniz varsa kullanmadan önce içeriği kontrol edin. Cildinizde tahriş olursa kullanımı bırakın ve doktorunuza danışın.",
              },
              {
                q: "Kargo ne kadar sürer?",
                a: "Siparişiniz 2-4 iş günü içinde kargoya verilir ve adresinize teslim edilir. Kargo ücretsizdir.",
              },
              {
                q: "İade koşulları neler?",
                a: "Ürünü teslim aldıktan sonra 14 gün içinde iade edebilirsiniz. Ürün kullanılmamış ve orijinal ambalajında olmalıdır. Detaylı bilgi için İade Koşulları sayfamızı inceleyebilirsiniz.",
              },
            ].map((faq, index) => (
              <Card key={index} className="border-2 hover:border-primary/50 transition-colors">
                <CardContent className="p-0">
                  <button
                    onClick={() => setOpenFaq(openFaq === index ? null : index)}
                    className="w-full p-5 flex items-center justify-between text-left hover:bg-muted/30 transition-colors rounded-lg"
                  >
                    <span className="font-semibold pr-4 text-sm md:text-base">{faq.q}</span>
                    <ChevronDown
                      className={`h-5 w-5 flex-shrink-0 transition-transform text-primary ${openFaq === index ? "rotate-180" : ""}`}
                    />
                  </button>
                  {openFaq === index && (
                    <div className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed">{faq.a}</div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted/50 border-t-2 border-border py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-2xl mb-3 text-primary">NOVABIOSALE</h3>
              <p className="text-sm text-muted-foreground mb-3">Doğal ve kaliteli kozmetik ürünler</p>
              <p className="text-xs text-muted-foreground font-mono">Mersis: 0748080637100001</p>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wide">Yasal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Gizlilik Politikası
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    İade Koşulları
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Mesafeli Satış Sözleşmesi
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Kullanım Koşulları
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wide">İletişim</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Email: support@novabiosale.com</li>
                <li>Telefon: +90 (XXX) XXX XX XX</li>
                <li>Çalışma Saatleri: Hafta içi 09:00 - 18:00</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-6 text-center text-sm text-muted-foreground space-y-2">
            <p>© 2025 NOVABIOSALE. Tüm hakları saklıdır.</p>
            <p className="text-xs">
              Bu ürün kozmetik bir üründür. Tıbbi bir ürün değildir ve hastalıkların tedavisinde kullanılmaz.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
