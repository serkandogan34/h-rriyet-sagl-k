"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function CTASection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [quantity, setQuantity] = useState(1)

  return (
    <section id="cta-section" ref={ref} className="py-20 bg-gradient-to-b from-primary/5 to-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
              Ağrısız Bir Hayat <span className="text-primary">Bir Tık Uzağınızda</span>
            </h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Bugün sipariş verin, yarın ağrınızdan kurtulmaya başlayın.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-card p-8 md:p-12 rounded-2xl shadow-2xl"
          >
            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div>
                <img src="/pain-relief-cream-tube-product.jpg" alt="Ağrı Kremi" className="w-full rounded-xl shadow-lg" />
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="text-3xl font-bold mb-4">Ağrı Giderici Krem</h3>
                <div className="text-4xl font-bold text-primary mb-6">
                  ₺299
                  <span className="text-lg text-muted-foreground line-through ml-3">₺499</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-3">
                    <span className="text-primary text-xl">✓</span>
                    <span>100ml - 2 ay kullanım</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-primary text-xl">✓</span>
                    <span>Doğal bileşenler</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-primary text-xl">✓</span>
                    <span>Ücretsiz kargo</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-primary text-xl">✓</span>
                    <span>30 gün para iade garantisi</span>
                  </li>
                </ul>
                <div className="flex items-center gap-4 mb-6">
                  <label className="font-semibold">Adet:</label>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => setQuantity(Math.max(1, quantity - 1))}>
                      -
                    </Button>
                    <Input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, Number.parseInt(e.target.value) || 1))}
                      className="w-20 text-center"
                    />
                    <Button variant="outline" size="sm" onClick={() => setQuantity(quantity + 1)}>
                      +
                    </Button>
                  </div>
                </div>
                <Button size="lg" className="w-full text-lg py-6 bg-primary hover:bg-primary/90">
                  Hemen Sipariş Ver - ₺{299 * quantity}
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4 pt-8 border-t border-border">
              <div className="flex items-center gap-3">
                <div className="text-3xl">🚚</div>
                <div>
                  <div className="font-semibold">Hızlı Teslimat</div>
                  <div className="text-sm text-muted-foreground">1-2 gün içinde</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-3xl">🔒</div>
                <div>
                  <div className="font-semibold">Güvenli Ödeme</div>
                  <div className="text-sm text-muted-foreground">SSL korumalı</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-3xl">💯</div>
                <div>
                  <div className="font-semibold">Memnuniyet Garantisi</div>
                  <div className="text-sm text-muted-foreground">30 gün iade</div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-8 text-center"
          >
            <p className="text-sm text-muted-foreground">⚡ Son 24 saatte 127 kişi sipariş verdi</p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
