"use client"

import { motion, AnimatePresence } from "framer-motion"
import { MessageCircle, X } from "lucide-react"
import { useState, useEffect } from "react"

export default function FloatingWhatsApp() {
  const [isExpanded, setIsExpanded] = useState(false)
  const [showPulse, setShowPulse] = useState(true)

  useEffect(() => {
    // Show pulse animation for first 5 seconds
    const timer = setTimeout(() => setShowPulse(false), 5000)
    return () => clearTimeout(timer)
  }, [])

  const whatsappNumber = "905XXXXXXXXX" // Replace with actual number
  const message = encodeURIComponent("Merhaba! Ağrı kesici krem hakkında bilgi almak istiyorum.")

  const handleWhatsAppClick = () => {
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, "_blank")
  }

  return (
    <>
      {/* Floating Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
      >
        {/* Pulse Animation */}
        {showPulse && (
          <motion.div
            className="absolute inset-0 rounded-full bg-emerald-500"
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.7, 0, 0.7],
            }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
        )}

        {/* Main Button */}
        <motion.button
          onClick={() => setIsExpanded(!isExpanded)}
          className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-2xl hover:shadow-emerald-500/50 transition-shadow"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <MessageCircle className="h-8 w-8" />

          {/* Notification Badge */}
          <motion.div
            className="absolute -top-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-xs font-bold"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
          >
            1
          </motion.div>
        </motion.button>

        {/* Expanded Card */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.8 }}
              className="absolute bottom-20 right-0 w-80 rounded-2xl bg-white p-6 shadow-2xl"
            >
              <button
                onClick={() => setIsExpanded(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="mb-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600">
                    <MessageCircle className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">Sağlık Danışmanı</h3>
                    <div className="flex items-center gap-1 text-sm text-emerald-600">
                      <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                      Çevrimiçi
                    </div>
                  </div>
                </div>

                <div className="rounded-lg bg-gray-50 p-4 mb-4">
                  <p className="text-sm text-gray-700 mb-2">👋 Merhaba! Size nasıl yardımcı olabilirim?</p>
                  <p className="text-xs text-gray-500">
                    Ortalama yanıt süresi: <span className="font-semibold text-emerald-600">2 dakika</span>
                  </p>
                </div>

                <button
                  onClick={handleWhatsAppClick}
                  className="w-full rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 px-6 py-4 font-bold text-white shadow-lg hover:shadow-xl transition-all hover:scale-105"
                >
                  WhatsApp'tan Yazın
                </button>

                <p className="mt-3 text-center text-xs text-gray-500">🔒 Güvenli ve gizli görüşme</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </>
  )
}
