"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function TrustSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Güvenle Kullanın</h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-card p-8 rounded-xl shadow-lg mb-8"
          >
            <h3 className="text-xl font-bold mb-4">İçindekiler</h3>
            <div className="grid md:grid-cols-2 gap-4 text-sm text-muted-foreground">
              <div>
                <p className="font-semibold text-foreground mb-2">Soğutucu Bileşenler:</p>
                <ul className="space-y-1">
                  <li>• Mentol</li>
                  <li>• Nane Yağı</li>
                  <li>• Okaliptüs Yağı</li>
                </ul>
              </div>
              <div>
                <p className="font-semibold text-foreground mb-2">Isıtıcı Bileşenler:</p>
                <ul className="space-y-1">
                  <li>• Capsaicin</li>
                  <li>• Zencefil Özü</li>
                  <li>• Arnika Montana</li>
                </ul>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-amber-50 border border-amber-200 p-6 rounded-xl mb-8"
          >
            <h3 className="text-lg font-bold mb-3 text-amber-900">⚠️ Önemli Uyarılar</h3>
            <ul className="space-y-2 text-sm text-amber-800">
              <li>• Bu ürün ilaç değildir, takviye gıda değildir.</li>
              <li>• Hamilelik ve emzirme döneminde doktorunuza danışın.</li>
              <li>• Açık yaralar ve hassas cilt bölgelerine uygulamayın.</li>
              <li>• İlk kullanımda küçük bir bölgede test edin.</li>
              <li>• Çocukların ulaşamayacağı yerde saklayın.</li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-center text-sm text-muted-foreground space-y-4"
          >
            <p>
              Bu ürün hastalıkların teşhis, tedavi veya önlenmesi amacıyla kullanılmaz. Kronik veya şiddetli ağrılarınız
              için mutlaka bir sağlık uzmanına başvurun.
            </p>
            <p>© 2025 Ağrı Kremi. Tüm hakları saklıdır.</p>
            <div className="flex justify-center gap-6 pt-4">
              <a href="#" className="hover:text-primary transition-colors">
                Gizlilik Politikası
              </a>
              <a href="#" className="hover:text-primary transition-colors">
                Kullanım Koşulları
              </a>
              <a href="#" className="hover:text-primary transition-colors">
                İletişim
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
