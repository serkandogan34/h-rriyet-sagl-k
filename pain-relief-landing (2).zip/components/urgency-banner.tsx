"use client"

import { motion } from "framer-motion"
import { Clock, TrendingUp } from "lucide-react"
import { useEffect, useState } from "react"

export default function UrgencyBanner() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59,
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <motion.div
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-r from-red-600 via-red-500 to-orange-500 text-white py-3 shadow-lg"
    >
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-center">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 animate-bounce" />
            <span className="font-bold">⚡ ÖZEL KAMPANYA!</span>
          </div>

          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            <span className="text-sm">Kampanya Bitimine:</span>
            <div className="flex gap-2 font-mono font-bold">
              <span className="bg-white/20 px-2 py-1 rounded">{String(timeLeft.hours).padStart(2, "0")}</span>
              <span>:</span>
              <span className="bg-white/20 px-2 py-1 rounded">{String(timeLeft.minutes).padStart(2, "0")}</span>
              <span>:</span>
              <span className="bg-white/20 px-2 py-1 rounded">{String(timeLeft.seconds).padStart(2, "0")}</span>
            </div>
          </div>

          <span className="text-sm font-semibold">
            Sadece <span className="text-yellow-300 text-lg">12 adet</span> kaldı!
          </span>
        </div>
      </div>
    </motion.div>
  )
}
