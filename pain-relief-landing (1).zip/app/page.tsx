import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import EmpathySection from "@/components/empathy-section"
import ScienceSection from "@/components/science-section"
import SolutionSection from "@/components/solution-section"
import PersonalizationSection from "@/components/personalization-section"
import SocialProofSection from "@/components/social-proof-section"
import CTASection from "@/components/cta-section"
import TrustSection from "@/components/trust-section"

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen pt-16 md:pt-20">
        <HeroSection />
        <EmpathySection />
        <ScienceSection />
        <SolutionSection />
        <PersonalizationSection />
        <SocialProofSection />
        <CTASection />
        <TrustSection />
      </main>
    </>
  )
}
