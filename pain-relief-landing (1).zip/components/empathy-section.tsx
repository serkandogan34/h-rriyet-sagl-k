"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function EmpathySection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Yalnız Değilsiniz</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Milyonlarca insan her gün kronik ağrıyla mücadele ediyor.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                stat: "%80",
                description: "İnsanlar hayatlarının bir döneminde bel ağrısı yaşıyor",
              },
              {
                stat: "%30",
                description: "Yetişkinler kronik eklem ağrısından muzdarip",
              },
              {
                stat: "%60",
                description: "Ağrı nedeniyle iş verimliliği düşüyor",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="bg-card p-8 rounded-xl shadow-lg text-center"
              >
                <div className="text-5xl font-bold text-primary mb-4">{item.stat}</div>
                <p className="text-muted-foreground leading-relaxed">{item.description}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-12 text-center"
          >
            <p className="text-xl text-foreground leading-relaxed">Ağrınız gerçek. Çözümü de öyle.</p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
