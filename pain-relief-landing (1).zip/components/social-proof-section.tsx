"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function SocialProofSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="social-proof-section" ref={ref} className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="bg-gradient-to-br from-primary/10 to-secondary/10 p-12 rounded-2xl shadow-xl"
          >
            <div className="text-6xl mb-6 text-center">💬</div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center text-balance">Komşum Almanya'dan Getirdi</h2>
            <div className="space-y-6 text-lg leading-relaxed text-muted-foreground">
              <p>"Yıllardır bel ağrısıyla yaşıyordum. Doktorlar, ilaçlar, fizik tedavi... Hiçbiri kalıcı olmadı."</p>
              <p>
                "Bir gün komşum Almanya'dan döndü ve bu kremi getirdi. 'Orada herkes kullanıyor' dedi. İlk kullandığımda
                şüpheliydim ama 10 dakika sonra fark ettim - ağrım azalmıştı!"
              </p>
              <p className="font-semibold text-foreground">
                "Şimdi her sabah uyanıyorum ve ağrı olmadan güne başlayabiliyorum. Torunlarımla oynayabiliyorum. Hayatım
                geri geldi."
              </p>
              <div className="pt-6 border-t border-border">
                <p className="font-semibold text-foreground">— Ayşe H., 58</p>
                <p className="text-sm text-muted-foreground">İstanbul</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mt-12 grid md:grid-cols-3 gap-6"
          >
            {[
              { rating: "4.8/5", label: "Ortalama Değerlendirme" },
              { rating: "15,000+", label: "Mutlu Müşteri" },
              { rating: "%94", label: "Tekrar Satın Alma" },
            ].map((stat, index) => (
              <div key={index} className="text-center p-6 bg-card rounded-xl shadow">
                <div className="text-3xl font-bold text-primary mb-2">{stat.rating}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
