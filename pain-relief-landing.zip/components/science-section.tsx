"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function ScienceSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Peki Ağrı Neden <span className="text-secondary">Geçmiyor?</span>
            </h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Çünkü çoğu çözüm sadece belirtileri gizliyor, kökeni tedavi etmiyor.
            </p>
          </motion.div>

          <div className="space-y-8">
            {[
              {
                title: "İltihaplanma",
                description: "Kronik ağrının temel nedeni sürekli iltihaplanmadır. Vücudunuz sürekli alarm durumunda.",
              },
              {
                title: "Kan Dolaşımı",
                description: "Zayıf kan dolaşımı iyileşmeyi yavaşlatır ve ağrıyı kronikleştirir.",
              },
              {
                title: "Kas Gerginliği",
                description: "Gergin kaslar sinirlere baskı yapar ve ağrı döngüsünü sürdürür.",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -30 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="bg-card p-8 rounded-xl shadow-lg border-l-4 border-secondary"
              >
                <h3 className="text-2xl font-bold mb-4 text-secondary">{item.title}</h3>
                <p className="text-muted-foreground leading-relaxed text-lg">{item.description}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="mt-12 text-center bg-muted/50 p-8 rounded-xl"
          >
            <p className="text-xl font-semibold text-foreground leading-relaxed">
              Gerçek çözüm, bu üç sorunu aynı anda ele almaktır.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
