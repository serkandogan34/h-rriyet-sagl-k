"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef, useState } from "react"

export default function SolutionSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [activeTab, setActiveTab] = useState<"ice" | "fire">("ice")

  return (
    <section id="solution-section" ref={ref} className="py-20 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
              Önce <span className="text-secondary">Buz</span>, Sonra <span className="text-accent">Ateş</span>
            </h2>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
              Doğanın en güçlü iki prensibi: Soğutma ve ısıtma. İkisini bir arada kullanarak ağrıyı köküne iner.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-0 rounded-2xl overflow-hidden shadow-2xl">
            {/* Ice Side */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className={`relative p-12 cursor-pointer transition-all duration-500 ${
                activeTab === "ice" ? "bg-secondary scale-105 z-10" : "bg-secondary/80"
              }`}
              onClick={() => setActiveTab("ice")}
              onMouseEnter={() => setActiveTab("ice")}
            >
              <div className="relative z-10">
                <div className="text-6xl mb-6">❄️</div>
                <h3 className="text-3xl font-bold mb-4 text-white">1. Buz Etkisi</h3>
                <p className="text-white/90 leading-relaxed text-lg mb-6">
                  Mentol ve doğal soğutucu bileşenler anında iltihaplanmayı azaltır.
                </p>
                <ul className="space-y-3 text-white/90">
                  <li className="flex items-start gap-3">
                    <span className="text-2xl">✓</span>
                    <span>İltihaplanmayı azaltır</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-2xl">✓</span>
                    <span>Şişliği düşürür</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-2xl">✓</span>
                    <span>Anında rahatlama</span>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Fire Side */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className={`relative p-12 cursor-pointer transition-all duration-500 ${
                activeTab === "fire" ? "bg-accent scale-105 z-10" : "bg-accent/80"
              }`}
              onClick={() => setActiveTab("fire")}
              onMouseEnter={() => setActiveTab("fire")}
            >
              <div className="relative z-10">
                <div className="text-6xl mb-6">🔥</div>
                <h3 className="text-3xl font-bold mb-4 text-white">2. Ateş Etkisi</h3>
                <p className="text-white/90 leading-relaxed text-lg mb-6">
                  Capsaicin ve ısıtıcı bileşenler kan dolaşımını hızlandırır ve iyileşmeyi tetikler.
                </p>
                <ul className="space-y-3 text-white/90">
                  <li className="flex items-start gap-3">
                    <span className="text-2xl">✓</span>
                    <span>Kan dolaşımını artırır</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-2xl">✓</span>
                    <span>Kasları gevşetir</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-2xl">✓</span>
                    <span>Uzun süreli iyileşme</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-12 text-center bg-primary/10 p-8 rounded-xl"
          >
            <p className="text-xl font-semibold text-foreground leading-relaxed">
              Bu iki etkinin kombinasyonu, ağrıyı hem anında hem de kalıcı olarak giderir.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
