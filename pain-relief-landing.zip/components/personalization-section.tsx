"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef, useState } from "react"
import { Button } from "@/components/ui/button"

const bodyParts = [
  { id: "back", label: "Bel", icon: "🦴" },
  { id: "knee", label: "Diz", icon: "🦵" },
  { id: "shoulder", label: "Omuz", icon: "💪" },
  { id: "neck", label: "Boyun", icon: "🧘" },
  { id: "ankle", label: "Ayak Bileği", icon: "🦶" },
  { id: "wrist", label: "Bilek", icon: "✋" },
]

export default function PersonalizationSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [selectedPart, setSelectedPart] = useState<string | null>(null)

  return (
    <section ref={ref} className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Ağrınız Nerede?</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Her vücut bölgesi için etkili. Sizin ağrınız için nasıl çalışacağını görün.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-12">
            {bodyParts.map((part, index) => (
              <motion.div
                key={part.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Button
                  variant={selectedPart === part.id ? "default" : "outline"}
                  className={`w-full h-24 text-lg flex flex-col gap-2 ${
                    selectedPart === part.id ? "bg-primary text-primary-foreground" : "hover:bg-primary/10"
                  }`}
                  onClick={() => setSelectedPart(part.id)}
                >
                  <span className="text-3xl">{part.icon}</span>
                  <span>{part.label}</span>
                </Button>
              </motion.div>
            ))}
          </div>

          {selectedPart && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-card p-8 rounded-xl shadow-lg"
            >
              <h3 className="text-2xl font-bold mb-4 text-primary">
                {bodyParts.find((p) => p.id === selectedPart)?.label} Ağrısı İçin
              </h3>
              <p className="text-muted-foreground leading-relaxed text-lg mb-6">
                Kremimiz bu bölgedeki iltihaplanmayı azaltır, kan dolaşımını artırır ve kasları gevşeterek ağrınızı hem
                anında hem de kalıcı olarak giderir.
              </p>
              <div className="flex gap-4">
                <div className="flex-1 bg-secondary/10 p-4 rounded-lg">
                  <div className="text-3xl mb-2">⚡</div>
                  <div className="font-semibold">Hızlı Etki</div>
                  <div className="text-sm text-muted-foreground">5-10 dakika</div>
                </div>
                <div className="flex-1 bg-primary/10 p-4 rounded-lg">
                  <div className="text-3xl mb-2">🎯</div>
                  <div className="font-semibold">Hedefli Tedavi</div>
                  <div className="text-sm text-muted-foreground">Doğrudan bölgeye</div>
                </div>
                <div className="flex-1 bg-accent/10 p-4 rounded-lg">
                  <div className="text-3xl mb-2">♻️</div>
                  <div className="font-semibold">Uzun Süreli</div>
                  <div className="text-sm text-muted-foreground">6-8 saat rahatlama</div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  )
}
